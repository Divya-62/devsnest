class Test{
    print(){
      console.log("HelloWorld");
    }
  }
  
  module.exports=Test;
var Text= require("./require");

var obj=new Text();
console.log(obj.print());